


def test_import_tmulib():
    import tmu.tmulib